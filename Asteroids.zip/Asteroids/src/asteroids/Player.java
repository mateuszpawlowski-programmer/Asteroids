/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids;

import java.util.ArrayList;

/**
 *
 * @author M
 */
public class Player {
    
    double pos_x,pos_y;
    double vx=0,vy=0;
    double rot=0;
    double accelerate=0.01;
    
    double px1,py1;
    double px2,py2;
    double px3,py3;
    
    double energy=100;
    
    ArrayList<Bullet> bullets=new ArrayList<Bullet>();
    
    Player()
    {
    pos_x=320;pos_y=120;
    
    /*
    px1=pos_x;py1=pos_y+3;
    px2=pos_x-3;py2=pos_y-3;
    px3=pos_x+3;py3=pos_y-3;
    */
            
    }
    
    
    public void calculate_points()
    {
        double angle=(rot*3.14)/180;
        
        px1=Math.cos(angle)*13;
        py1=Math.sin(angle)*13;
        
        angle=((rot+90+45)*3.14)/180;
        px2=Math.cos(angle)*13;
        py2=Math.sin(angle)*13;
        
        angle=((rot+90+180-45)*3.14)/180;
        px3=Math.cos(angle)*13;
        py3=Math.sin(angle)*13;
        
        px1=pos_x+px1;
        py1=pos_y+py1;
        
        px2=pos_x+px2;
        py2=pos_y+py2;
        
        px3=pos_x+px3;
        py3=pos_y+py3;
    }
    
    public void shoot()
    {
    this.calculate_points();
    Bullet b=new Bullet(this.px1,this.py1,rot,vx,vy);
    bullets.add(b);
    }
    public void move()
    {
    pos_x=pos_x+vx;
    pos_y=pos_y+vy;
    
        if(pos_x>640) pos_x=0;
        if(pos_y>480) pos_y=0;
        
        if(pos_x<0) pos_x=640;
        if(pos_y<0) pos_y=480;
    }
    
    public void up()
    {
        double angle=(rot*180)/3.14;
        angle=(rot*3.14)/180;
        vy=vy+Math.sin(angle)*accelerate;
        vx=vx+Math.cos(angle)*accelerate;
        //sin r =y
        //cos r =x
    }
    
    public void rotate_right()
    {
     rot=rot+10;
     if(rot==360) rot=0;
    }
    
    public void rotate_left()
    {
     rot=rot-10;
     if(rot==-10) rot=350;
    }
    
}
