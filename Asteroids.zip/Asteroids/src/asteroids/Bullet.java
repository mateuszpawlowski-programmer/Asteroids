/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids;

/**
 *
 * @author M
 */
public class Bullet {

double px,py;
double vx,vy;

boolean alive=true;

Bullet(double posx,double posy,double rot,double vecx,double vecy)
{
    this.px=posx;
    this.py=posy;
    
    double angle=(rot*3.14)/180;
    double px1=Math.cos(angle)*0.2;
    double py1=Math.sin(angle)*0.2;
        
    this.vx=px1;
    this.vy=py1;
    
    vx=vx+vecx;
    vy=vy+vecy;
}

public void move()
{
px=px+vx;
py=py+vy;
}
}
