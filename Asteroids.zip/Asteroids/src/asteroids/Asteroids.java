/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author M
 */
public class Asteroids extends JPanel implements Runnable,KeyListener{

    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("Asteroids");
    public Thread thread;

    public Player player;
    ArrayList<Rock> rocks=new ArrayList<Rock>();
    
    Asteroids()
    {
    player=new Player();
    this.addKeyListener(this);
    setFocusable(true);
    setFocusTraversalKeysEnabled(false);
    
    
    for(int i=0;i<10;i++) rocks.add(new Rock());
                
                
    }
    
    public static void main(String[] args) {
        Asteroids a=new Asteroids();
        a.panel = a;
        a.frame = new JFrame("Asteroids");
        a.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a.frame.getContentPane().add(a.panel);
        a.panel.setSize(300, 300);
        a.frame.setLocation(500, 300);
        a.frame.pack();
        a.frame.show();
        a.thread=new Thread(a);
        a.thread.start();
    }

    
    @Override
    public void run() {
        while(true){
        try{
            
        player.calculate_points();
        player.move();
        
        check_collision_bullet_with_asteroid();
        check_collision_asteroid_with_player();
        
        
        
        this.repaint();    
        Thread.sleep(1);
        }catch(Exception exc){};
        }
    }
    
    public void check_collision_asteroid_with_player()
    {
    for(Rock r:rocks)
    {
       if(r.alive)
       {
          if(r.px>player.pos_x-10&&r.px<player.pos_x+10)
          {
             if(r.py>player.pos_y-10&&r.py<player.pos_y+10)
             {
             player.energy=player.energy-0.05;
             if(player.energy<=0) frame.dispose();
             }
          }
       }
    }
    }
    
    public void check_collision_bullet_with_asteroid()
    {
        double vx1,vx2,vy1,vy2;
        for(Bullet b:player.bullets)
        {
        if(b.alive){
        b.move();
        
        
        vx1=b.vx;
        vy1=b.vy;
        
        vx2=b.vx;
        vy2=b.vy;
            
            for(int ir=0;ir<rocks.size()-1;ir++)
            {
                Rock r=rocks.get(ir);
                if(r.alive&&b.alive){

                    if(b.py>=r.py-10&&b.py<=r.py+10)
                    {
                    if(b.px>=r.px-10&&b.px<=r.px+10)
                    {
                        r.alive=false;
                        b.alive=false;
                        
                        if(r.size==1){
                        rocks.add(new Rock(r.px,r.py,-vy1/4,vx1/4,2));
                        rocks.add(new Rock(r.px,r.py,vy2/4,-vx2/4,2));
                        }
                    }
                    }
                }
            }
        }
        }
    }
    
    public void up()
    {
    player.up();
    }
    
    public void down()
    {
    player.shoot();
    }
    
    public void left()
    {
    player.rotate_left();
    }
    
    public void right()
    {
    player.rotate_right();
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 480);
    }
    
    public void paintComponent(Graphics g){
    	super.paintComponent(g);
        g.setColor(Color.white);
        g.fillRect(0, 0, 640, 480);
        
            int h=50;
            g.setColor(Color.black);
            g.drawRect(630-300, 70-h, 300, 15);
            g.setColor(new Color(0,255,0));
            g.fillRect(630-299, 71-h, (int)player.energy*3-1, 14);
            
        g.setColor(Color.blue);
        player.calculate_points();
        g.drawLine((int)player.px1,(int)player.py1,(int)player.px2,(int)player.py2);
        g.drawLine((int)player.px1,(int)player.py1,(int)player.px3,(int)player.py3);
        g.drawLine((int)player.px2,(int)player.py2,(int)player.px3,(int)player.py3);
        
        double vx1,vx2,vy1,vy2;
        
        for(Bullet b:player.bullets)
        {
        if(b.alive){
        g.drawLine((int)b.px,(int)b.py,(int)b.px,(int)b.py);
        g.fillRect((int)b.px-1,(int)b.py-1,2,2);
        }
        }
               
        for(Rock r:rocks)
        {
            if(r.alive){
            r.move();
            if(r.size==1) g.drawOval((int)r.px,(int)r.py, 15, 15);
            if(r.size==2) g.drawOval((int)r.px,(int)r.py, 10, 10);
            }
        }
     }

    @Override
    public void keyTyped(KeyEvent ke) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==87){up();}
        if(e.getKeyCode()==83){down();}
        if(e.getKeyCode()==65){left();}
        if(e.getKeyCode()==68){right();}
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        
    }
    
}
