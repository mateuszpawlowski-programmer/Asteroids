/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids;

import java.util.Random;

/**
 *
 * @author M
 */



public class Rock {

double px,py;
double vx,vy;

int size=1;

boolean alive=true;

Rock()
{
Random rnd=new Random();

px=rnd.nextInt(640);
py=rnd.nextInt(480);

vx=0.05*rnd.nextDouble();
vy=0.05*rnd.nextDouble();

if(rnd.nextInt(1)==1){vx=vx*-1;}
if(rnd.nextInt(1)==1){vy=vy*-1;}

}

Rock(double x,double y,double vecx,double vecy,int s)
{
px=x;
py=y;
vx=vecx;
vy=vecy;
size=s;
}

public void move()
{
px=px+vx;
py=py+vy;

        if(px>640) px=0;
        if(py>480) py=0;
        
        if(px<0) px=640;
        if(py<0) py=480;
}

}
